import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/cat.dart';

class CatService {
  static const String _baseUrl = 'https://api.thecatapi.com/v1';
  static const String _apiKey = 'live_1XyfUuvMgn68EkrkCi0FEDSFVt8ovpEbbF2cjyLx37HepmVkkAuDUgmxW4JTN8Yf';
  static const int _maxRetries = 3;
  static const Duration _timeout = Duration(seconds: 10);

  final http.Client _client;

  CatService({http.Client? client}) : _client = client ?? http.Client();

  Future<Cat?> fetchRandomCat() async {
    print('🐞 [DEBUG] Fetching cat...');
    for (int attempt = 0; attempt < _maxRetries; attempt++) {
      try {
        final response = await _client
            .get(
          Uri.parse('$_baseUrl/images/search?has_breeds=1'),
          headers: {'x-api-key': _apiKey},
        )
            .timeout(_timeout);

        print('🐞 [DEBUG] Response status: ${response.statusCode}');
        return _handleResponse(response);
      } on TimeoutException {
        print('🐞 [DEBUG] Timeout attempt ${attempt + 1}');
      } catch (e) {
        print('🐞 [DEBUG] Error: $e');
        if (attempt == _maxRetries - 1) rethrow;
      }
      await Future.delayed(Duration(seconds: 1 << attempt));
    }
    return null;
  }

  Cat? _handleResponse(http.Response response) {
    print('🐞 [DEBUG] Handling response...');
    switch (response.statusCode) {
      case 200:
        return _parseJson(response.body);
      default:
        print('🐞 [DEBUG] HTTP Error: ${response.statusCode}');
        throw Exception('Failed to load cat');
    }
  }

  Cat? _parseJson(String jsonString) {
    try {
      final data = jsonDecode(jsonString) as List;
      print('🐞 [DEBUG] Parsed JSON: ${data.length} items');
      if (data.isEmpty) {
        print('🐞 [DEBUG] Empty data array');
        return null;
      }
      final firstItem = data.first;
      print('🐞 [DEBUG] First item: $firstItem');
      return Cat.fromJson(firstItem);
    } catch (e) {
      print('🐞 [DEBUG] JSON Parse Error: $e');
      return null;
    }
  }
}